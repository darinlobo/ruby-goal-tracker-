class GoalsController < ApplicationController
  def index
  @goals = Goal.all
  end

  def show
  @goal = Goal.find(params[:id])
  end
  
  def new
  @goal = Goal.new
  end

def create
  @goal = current_user.goals.build(goal_params)
  if @goal.save
    redirect_to @goal
  else
    # debug code here
    render :new
  end
end

private

def goal_params
  params.require(:goal).permit(:name, :goal_value, :unit_of_measure)
  end
end

