class Goal < ApplicationRecord
  belongs_to :user
  has_many :items
  end
  `validates :name, presence: true`
  `validates :name, uniqueness: { case_sensitive: false }`
  `validates :goal_value, presence: true` 
  `validates :goal_value, numericality: { greater_than_0: true}`
  `validates :unit_of_measure, presence: true`
  `validates :unit_of_measure, inclusion: { in: %w, %kg, %km}`
