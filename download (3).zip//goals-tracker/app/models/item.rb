class Item < ApplicationRecord
  belongs_to :goal
end
